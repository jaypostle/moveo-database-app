import React from 'react';
import { FaHeart } from 'react-icons/fa';


export default function RemoveFavourites() {
  return (
    <div>
        <span>Remove From Favourites</span>
        <FaHeart />
    </div>
  )
}
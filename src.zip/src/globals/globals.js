
export const API_KEY = 'b88e3f6d75617b57568ea1668aa6b559';
export const appStorageName = 'movie-app-favs';